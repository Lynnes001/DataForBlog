from sklearn.cluster import Birch
from sklearn import metrics
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pandas.tools.plotting import parallel_coordinates
import warnings
warnings.filterwarnings("ignore")


dataset = pd.read_csv('iris.csv')
x = dataset.iloc[:, [0,1,2,3]].values
x1=dataset.iloc[:, [0,1,2,3]]

original=dataset.iloc[:, [0,1,2,3,4]]
y_pred = Birch(n_clusters = 3,threshold=0.1, branching_factor = 30).fit_predict(x)
x1["y_pred"] = y_pred

from pandas.tools.plotting import radviz
radviz(x1, "y_pred", colormap='rainbow').set_title('Iris_Clustering Result with input cluster number')
plt.show()

radviz(original, "label", colormap='rainbow').set_title('Iris_Original Data')
plt.show()

print("Adjusted Rand index", metrics.adjusted_rand_score(original['label'], x1['y_pred']))
print("Mutual Information based scores", metrics.adjusted_mutual_info_score(original['label'], x1['y_pred']))
print("V-measure", metrics.v_measure_score(original['label'], x1['y_pred']))
print("Calinski-Harabaz Index", metrics.calinski_harabaz_score(x, x1['y_pred']))
