from sklearn.cluster import Birch
from sklearn import metrics
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pandas.tools.plotting import parallel_coordinates
import warnings
warnings.filterwarnings("ignore")



dataset = pd.read_csv('wineoriginal.csv')
x = dataset.iloc[:, [1,2,3,4,5,6,7,8,9,10,11,12]].values
x1=dataset.iloc[:, [1,2,3,4,5,6,7,8,9,10,11,12]]

original=dataset.iloc[:, [0,1,2,3,4,5,6,7,8,9,10,11,12]]
y_pred = Birch(n_clusters = 3).fit_predict(x)
x1["y_pred"] = y_pred

from pandas.tools.plotting import radviz
radviz(x1, "y_pred", colormap='rainbow').set_title('Clustering Result - 12 dimensions')
plt.show()

radviz(original, "a", colormap='rainbow').set_title('Original Data - 12 dimensions')
plt.show()

print("Adjusted Rand index", metrics.adjusted_rand_score(original['a'], x1['y_pred']))
print("Mutual Information based scores", metrics.adjusted_mutual_info_score(original['a'], x1['y_pred']))
print("V-measure", metrics.v_measure_score(original['a'], x1['y_pred']))
print("Calinski-Harabaz Index", metrics.calinski_harabaz_score(x, x1['y_pred']))
