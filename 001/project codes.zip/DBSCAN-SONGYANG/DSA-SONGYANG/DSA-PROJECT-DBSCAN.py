
# coding: utf-8

# In[ ]:


import pandas as pd
from sklearn.cluster import DBSCAN
import matplotlib.pyplot as plt
import numpy as np
import time
get_ipython().magic(u'matplotlib inline')

data = pd.read_csv('IrisDataset\iris.data')  


# In[ ]:


X1 = data.iloc[0:150, [0,1]]
X2 = data.iloc[0:150, [2,3]]
# Y = data.iloc[0:50, [0, 2]]


plt.figure(1)
plt.plot(data.iloc[0:50,[0]], data.iloc[0:50,[1]], 'ro')
plt.plot(data.iloc[50:100,[0]], data.iloc[50:100,[1]], 'go')
plt.plot(data.iloc[100:150,[0]], data.iloc[100:150,[1]], 'bo')

plt.figure(2)
plt.plot(data.iloc[0:50,[2]], data.iloc[0:50,[3]], 'ro')
plt.plot(data.iloc[50:100,[2]], data.iloc[50:100,[3]], 'go')
plt.plot(data.iloc[100:150,[2]], data.iloc[100:150,[3]], 'bo')

plt.show()


# In[ ]:


# conjecture one, density influence

import pandas
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
get_ipython().magic(u'matplotlib inline')
from sklearn import metrics
from copy import deepcopy

# import data
data = pandas.read_csv("IrisDataset\iris2.csv")

plt.figure(2)
plt.title('Origin Data', loc='center')
plt.xlabel('petal length')
plt.ylabel('petal width')
plt.plot(data[u' petalL'][0:50], data[u' petalW'][0:50], 'ro')
plt.plot(data[u' petalL'][50:100], data[u' petalW'][50:100], 'go')
plt.plot(data[u' petalL'][100:150], data[u' petalW'][100:150], 'bo')

plt.show()

eps = 0.22;
MinPts = 5;

model = DBSCAN(eps, MinPts)
model.fit(data)

data['type'] = model.fit_predict(data)


plt.figure(3)
plt.title('DBCSCAN result with eps: ' +str(eps)+ ' min_samples: '+str(MinPts), loc='center')
plt.xlabel('petal length')
plt.ylabel('petal width')

colormap = deepcopy(data['type'])
for i in range(int(len(data['type']))):
    if( data['type'][i] == -1):
        colormap[i] = 'black'
    if( data['type'][i] == 0):
        colormap[i] = 'r'
    if( data['type'][i] == 1):
        colormap[i] = 'g'
    if( data['type'][i] == 2):
        colormap[i] = 'b'
    if( data['type'][i] == 3):
        colormap[i] = 'm'
    if( data['type'][i] == 4):
        colormap[i] = 'c'
    if( data['type'][i] == 5):
        colormap[i] = 'y'

plt.scatter(data[u' petalL'].values, data[u' petalW'].values, c=colormap.values)

plt.show()

# clusters = len(set(data['type'] )) - (1 if -1 in labels else 0)

data_true=[]
for i in range(0,50):
    data_true.append(0)
for i in range(0,50):
    data_true.append(1)
for i in range(0,50):
    data_true.append(2)


# adjusted_rand_index, [-1, 1] 1 is the best
ari = metrics.adjusted_rand_score(data_true, data['type'])

# Mutual Information based scores, [0, 1] 1 is the best
mi = metrics.adjusted_mutual_info_score(data_true, data['type'])

print ari, mi

# Homogeneity, completeness and V-measure
h = metrics.homogeneity_score(data_true, data['type'])
c = metrics.completeness_score(data_true, data['type'])
v = metrics.v_measure_score(data_true, data['type']) 

print h,c,v

# Fowlkes-Mallows scores
fmc = metrics.fowlkes_mallows_score(data_true, data['type'])

print fmc

# Silhouette Coefficient
sc = metrics.silhouette_score(data, data['type'], metric='euclidean')
print sc

# Calinski-Harabaz Index
chi = metrics.calinski_harabaz_score(data, data['type'])
print chi


# In[ ]:


# conjecture two, high dimension influence 4 features

import pandas
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
get_ipython().magic(u'matplotlib inline')

import datetime


# import data
raw_data = pandas.read_csv("IrisDataset\iris4.csv")
data = pandas.read_csv("IrisDataset\iris.data")

from pandas.tools.plotting import radviz
# radviz(data,  u' class')

plt.figure(22)
from pandas.tools.plotting import parallel_coordinates
parallel_coordinates(data, u' class', colormap='rainbow')

plt.figure(32)
radviz(data, u' class', colormap='rainbow')

eps = 0.42
MinPts = 5;
# metric = 'precomputed'

starttime = datetime.datetime.now()
#long running
#do something other

model = DBSCAN(eps, MinPts)
model.fit(raw_data)

raw_data['type'] = model.fit_predict(raw_data)

endtime = datetime.datetime.now()
print starttime, endtime, 'runtime:', (endtime - starttime).seconds

# plt.figure(3)
# plt.title('DBCSCAN result with eps: ' +str(eps)+ ' min_samples: '+str(MinPts), loc='center')
# plt.xlabel('petal length')
# plt.ylabel('petal width')
# plt.scatter(
#     data[u' petalL'], 
#     data[u' petalW'],
#     c=data['type']
# )

# plt.show()
# print raw_data['type'].values

# clusters = len(set(data['type'] )) - (1 if -1 in labels else 0)

plt.figure(23)

parallel_coordinates(raw_data, u'type', colormap='rainbow')

plt.figure(33)
radviz(raw_data,  u'type', colormap='rainbow')


data_true=[]
for i in range(0,50):
    data_true.append(0)
for i in range(0,50):
    data_true.append(1)
for i in range(0,50):
    data_true.append(2)


# adjusted_rand_index, [-1, 1] 1 is the best
ari = metrics.adjusted_rand_score(data_true, raw_data['type'])

# Mutual Information based scores, [0, 1] 1 is the best
mi = metrics.adjusted_mutual_info_score(data_true, raw_data['type'])

print ari, mi

# Homogeneity, completeness and V-measure
h = metrics.homogeneity_score(data_true, raw_data['type'])
c = metrics.completeness_score(data_true, raw_data['type'])
v = metrics.v_measure_score(data_true, raw_data['type']) 

print h,c,v

# Fowlkes-Mallows scores
fmc = metrics.fowlkes_mallows_score(data_true, raw_data['type'])

print fmc

# Silhouette Coefficient
sc = metrics.silhouette_score(raw_data, raw_data['type'], metric='euclidean')
print sc

# Calinski-Harabaz Index
chi = metrics.calinski_harabaz_score(raw_data, raw_data['type'])
print chi


# In[ ]:


# conjecture two, high dimension influence 13 features w/ wine dataset

import pandas
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
get_ipython().magic(u'matplotlib inline')

import datetime


# import data
raw_data = pandas.read_csv("WineDataset\winecp131.csv")
data = pandas.read_csv("WineDataset\winecp1.csv")

print data.columns

from pandas.tools.plotting import radviz
# radviz(data,  u' class')

plt.figure(22)
from pandas.tools.plotting import parallel_coordinates
parallel_coordinates(data, u'class', colormap='rainbow')
plt.title('origin data')

plt.figure(32)
radviz(data, u'class', colormap='rainbow')
plt.title('origin data')
# eps = 24
# MinPts = 9

eps = 35.5
MinPts = 5

starttime = datetime.datetime.now()
#long running
#do something other

model = DBSCAN(eps, MinPts)
model.fit(raw_data)



raw_data['type'] = model.fit_predict(raw_data)

endtime = datetime.datetime.now()

# plt.figure(3)
# plt.title('DBCSCAN result with eps: ' +str(eps)+ ' min_samples: '+str(MinPts), loc='center')
# plt.xlabel('petal length')
# plt.ylabel('petal width')
# plt.scatter(
#     data[u' petalL'], 
#     data[u' petalW'],
#     c=data['type']
# )

# plt.show()
# print raw_data['type'].values

# clusters = len(set(data['type'] )) - (1 if -1 in labels else 0)

plt.figure(23)
parallel_coordinates(raw_data, u'type', colormap='rainbow')
plt.title('clustering data')


plt.figure(33)
radviz(raw_data,  u'type', colormap='rainbow')
plt.title('clustering data')
# print raw_data


data_true=data[u'class']

print raw_data['type'].values
print data_true.values

# adjusted_rand_index, [-1, 1] 1 is the best
ari = metrics.adjusted_rand_score(data_true, raw_data['type'])

# Mutual Information based scores, [0, 1] 1 is the best
mi = metrics.adjusted_mutual_info_score(data_true, raw_data['type'])

print ari, mi

# Homogeneity, completeness and V-measure
h = metrics.homogeneity_score(data_true, raw_data['type'])
c = metrics.completeness_score(data_true, raw_data['type'])
v = metrics.v_measure_score(data_true, raw_data['type']) 

print h,c,v

# Fowlkes-Mallows scores
fmc = metrics.fowlkes_mallows_score(data_true, raw_data['type'])

print fmc

# Silhouette Coefficient
sc = metrics.silhouette_score(raw_data, raw_data['type'], metric='euclidean')
print sc

# Calinski-Harabaz Index
chi = metrics.calinski_harabaz_score(raw_data, raw_data['type'])
print chi


# In[ ]:


print(__doc__)

import numpy as np

from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.datasets.samples_generator import make_blobs
from sklearn.preprocessing import StandardScaler


# #############################################################################
# Generate sample data
centers = [[1, 1], [-1, -1], [1, -1]]
X, labels_true = make_blobs(n_samples=750, centers=centers, cluster_std=0.4,
                            random_state=0)

X = StandardScaler().fit_transform(X)

print X
# #############################################################################
# Compute DBSCAN
db = DBSCAN(eps=0.3, min_samples=10).fit(X)
core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
core_samples_mask[db.core_sample_indices_] = True
labels = db.labels_

# Number of clusters in labels, ignoring noise if present.
n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)

print('Estimated number of clusters: %d' % n_clusters_)
print("Homogeneity: %0.3f" % metrics.homogeneity_score(labels_true, labels))
print("Completeness: %0.3f" % metrics.completeness_score(labels_true, labels))
print("V-measure: %0.3f" % metrics.v_measure_score(labels_true, labels))
print("Adjusted Rand Index: %0.3f"
      % metrics.adjusted_rand_score(labels_true, labels))
print("Adjusted Mutual Information: %0.3f"
      % metrics.adjusted_mutual_info_score(labels_true, labels))
print("Silhouette Coefficient: %0.3f"
      % metrics.silhouette_score(X, labels))

# #############################################################################
# Plot result
import matplotlib.pyplot as plt

# Black removed and is used for noise instead.
unique_labels = set(labels)
colors = [plt.cm.Spectral(each)
          for each in np.linspace(0, 1, len(unique_labels))]
for k, col in zip(unique_labels, colors):
    if k == -1:
        # Black used for noise.
        col = [0, 0, 0, 1]

    class_member_mask = (labels == k)

    xy = X[class_member_mask & core_samples_mask]
    plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
             markeredgecolor='k', markersize=14)

    xy = X[class_member_mask & ~core_samples_mask]
    plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
             markeredgecolor='k', markersize=6)

plt.title('Estimated number of clusters: %d' % n_clusters_)
plt.show()


# In[ ]:


from numpy import *  
import pandas as pd
from sklearn.cluster import DBSCAN
import matplotlib.pyplot as plt
import seaborn as sns
import time
get_ipython().magic(u'matplotlib inline')

data11 = pd.read_csv("IrisDataset/xy.csv")
data12 = pd.read_csv("IrisDataset/xy2.csv")

# print data11['x']

plt.plot(data11['x'], data11['y'], 'ro')
plt.plot(data11['y'],data11['x'], 'go')

