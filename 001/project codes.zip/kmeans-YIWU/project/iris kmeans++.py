#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat May  5 01:27:17 2018

@author: dilemma
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 30 15:14:06 2018

@author: dilemma
"""
from sklearn.cluster import KMeans
from sklearn import metrics
import pandas as pd

import matplotlib.pyplot as plt
from pandas.tools.plotting import parallel_coordinates

dataset = pd.read_csv('iris.csv')



x = dataset.iloc[:, [0,1,2,3]].values

kmeans = KMeans(n_clusters = 3, init = 'k-means++', max_iter = 300, n_init = 10, random_state = 0)
y_kmeans = kmeans.fit_predict(x)
dataset["y_kmeans"] = kmeans.fit_predict(x)
plt.figure(1)
plt.scatter(x[y_kmeans == 0, 2], x[y_kmeans == 0, 3], c = 'blue')
plt.scatter(x[y_kmeans == 1, 2], x[y_kmeans == 1, 3],  c = 'red')
plt.scatter(x[y_kmeans == 2, 2], x[y_kmeans == 2, 3], c = 'green')

plt.scatter(kmeans.cluster_centers_[:, 2], kmeans.cluster_centers_[:,3], c = 'yellow',)

plt.show()

print(metrics.silhouette_score(x, y_kmeans, metric='euclidean'))

print(metrics.calinski_harabaz_score(x,y_kmeans))
truelabel=[]
a=0
while a<=49:
    truelabel.append(1)
    a+=1
b=0
while b<=49:
    truelabel.append(0)
    b+=1
c=0  
while c<=49:
    truelabel.append(2)
    c+=1
print(len(truelabel))
print(len(y_kmeans))
plt.figure(51)

print( metrics.adjusted_rand_score(truelabel, y_kmeans) )
print(metrics.adjusted_mutual_info_score(truelabel, y_kmeans)  )
print(metrics.v_measure_score(truelabel, y_kmeans)  )
parallel_coordinates(dataset,"y_kmeans",colormap='rainbow')