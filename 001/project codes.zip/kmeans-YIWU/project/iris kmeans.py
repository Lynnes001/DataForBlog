#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 30 15:14:06 2018

@author: dilemma
"""
from sklearn import datasets
import matplotlib.pyplot as plt
from sklearn import metrics
import numpy as np
import pandas as pd
from pandas.tools.plotting import parallel_coordinates
iris = datasets.load_iris()
X, y = iris.data, iris.target
data = X[:,[2,3]] # 为了便于可视化，只取两个维度
plt.scatter(data[:,0],data[:,1]);
dataset = pd.read_csv('iris.csv')
def distance(p1,p2):
    """
    Return Eclud distance between two points.
    p1 = np.array([0,0]), p2 = np.array([1,1]) => 1.414
    """
    tmp = np.sum((p1-p2)**2)
    return np.sqrt(tmp)

def rand_center(data,k):
    """Generate k center within the range of data set."""
    n = data.shape[1] # features   
    centroids = np.zeros((k,n)) # init with (0,0)....
    for i in range(n):
        dmin, dmax = np.min(data[:,i]), np.max(data[:,i])
        centroids[:,i] = dmin + (dmax - dmin) * np.random.rand(k)
    return centroids

def kmeans(data,k=3):
    def _distance(p1,p2):
        """
        Return Eclud distance between two points.
        p1 = np.array([0,0]), p2 = np.array([1,1]) => 1.414
        """
        tmp = np.sum((p1-p2)**2)
        return np.sqrt(tmp)
    def _rand_center(data,k):
        """Generate k center within the range of data set."""
        n = data.shape[1] # features
        centroids = np.zeros((k,n)) # init with (0,0)....
        for i in range(n):
            dmin, dmax = np.min(data[:,i]), np.max(data[:,i])
            centroids[:,i] = dmin + (dmax - dmin) * np.random.rand(k)
        return centroids
    
    def _converged(centroids1, centroids2):
        
        # if centroids not changed, we say 'converged'
         set1 = set([tuple(c) for c in centroids1])
         set2 = set([tuple(c) for c in centroids2])
         
         return (set1 == set2)
        
    
    n = data.shape[0] # number of entries
    centroids = _rand_center(data,k)
    label = np.zeros(n,dtype=np.int) # track the nearest centroid
    assement = np.zeros(n) # for the assement of our model
    converged = False
    
    while not converged:
        old_centroids = np.copy(centroids)
        for i in range(n):
            # determine the nearest centroid and track it with label
            min_dist, min_index = np.inf, -1
            for j in range(k):
                dist = _distance(data[i],centroids[j])
                if dist < min_dist:
                    min_dist, min_index = dist, j
                    label[i] = j
            assement[i] = _distance(data[i],centroids[label[i]])**2
        
        # update centroid
        
        converged =True
    return centroids, label, np.sum(assement)

best_assement = np.inf
best_centroids = None
best_label = None

for i in range(10):
    centroids, label, assement = kmeans(data,3)
    if assement < best_assement:
        best_assement = assement
        best_centroids = centroids
        best_label = label

data0 = data[best_label==0]
data1 = data[best_label==1]
data2 = data[best_label==2]


plt.scatter(data0[:,0],data0[:,1],c='b')
plt.scatter(data1[:,0],data1[:,1],c='r')
plt.scatter(data2[:,0],data2[:,1],c='g')
plt.scatter(centroids[:,0],centroids[:,1],c='yellow')

plt.show()
#print(metrics.calinski_harabaz_score(X,best_label))
#print(metrics.silhouette_score(X,best_label, metric='euclidean'))
#print(best_label)

dataset["y_kmeans"]=best_label
parallel_coordinates(dataset,"y_kmeans",colormap='rainbow')
truelabel=[]
a=0
while a<=49:
    truelabel.append(1)
    a+=1
b=0
while b<=49:
    truelabel.append(0)
    b+=1
c=0  
while c<=49:
    truelabel.append(2)
    c+=1
#print( metrics.adjusted_rand_score(truelabel, best_label) )
print(metrics.adjusted_mutual_info_score(truelabel, best_label)  )
print(metrics.v_measure_score(truelabel, best_label)  )