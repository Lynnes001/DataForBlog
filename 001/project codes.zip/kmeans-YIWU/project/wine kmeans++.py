#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 30 15:14:06 2018

@author: dilemma
"""
from sklearn.cluster import KMeans
from sklearn import metrics
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pandas.tools.plotting import parallel_coordinates



dataset = pd.read_csv('wine.csv')
dataset0 = pd.read_csv('wineoriginal.csv')
x = dataset.iloc[:, [0,1,2,3,4,5,6,7,8,9]].values
x1=dataset.iloc[:, [0,1,2,3,5,6,7,8,9,10]]

dataset1=dataset0.iloc[:, [0,1,2,3,4,6,7,8,9,10,11]]
kmeans = KMeans(n_clusters = 3, init = 'k-means++', max_iter = 300, n_init = 10, random_state = 0)
y_kmeans = kmeans.fit_predict(x)
x1["y_kmeans"] = kmeans.fit_predict(x) #加标签

plt.scatter(x[y_kmeans == 0, 0], x[y_kmeans == 0, 1], c = 'blue')
plt.scatter(x[y_kmeans == 1, 0], x[y_kmeans == 1, 1],  c = 'red')
plt.scatter(x[y_kmeans == 2, 0], x[y_kmeans == 2, 1], c = 'green')

plt.scatter(kmeans.cluster_centers_[:, 2], kmeans.cluster_centers_[:,3], c = 'yellow',)

plt.show()

parallel_coordinates(x1,"y_kmeans",colormap='rainbow') #分类后的图
plt.show()
parallel_coordinates(dataset1,"a",colormap='rainbow')  #原始的图
